#include <stdio.h>

int main (int argc, char **argv)
{
    char    stra[] = "abcdefghijkl";
    char    *strp =  "zyxwvutsrqpo";

    return 0;               // indicate successful run to Unix
}
