#ifndef _ITERS_
#define _ITERS_

#define ITERATIONS	30000000

#endif	// _ITERS_
