int main()
{
	asm(
		"			any old thing			\n"
		"			whether or not			\n"
		"			it makes sense			\n"
	);
	return 0;
}
