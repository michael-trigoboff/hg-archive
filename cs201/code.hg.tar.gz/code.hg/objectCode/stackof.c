void fn()
{
	fn();
}

int main()
{
	fn();
}
