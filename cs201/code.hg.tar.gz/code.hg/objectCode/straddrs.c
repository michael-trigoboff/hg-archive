#include <stdio.h>

int main()
{
	char	*p =	"abcdefg";
	char	a[] =	"zyxwvut";

	printf("%s\n", p);
	printf("%s\n", a);

	return 0;
}
