#pragma GCC diagnostic ignored "-Wunused-but-set-variable"

#include <stdio.h>

int main (int argc, char **argv)
{
    int     x = 3;
    int     y = 4;
    int     z;
    
    z = x + y;
    
	printf("z = %d\n", z);
    return 0;
}
