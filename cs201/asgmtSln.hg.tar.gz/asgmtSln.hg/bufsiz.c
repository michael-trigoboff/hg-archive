#include <stdio.h>

int main()
{
	printf("BUFSIZ = %d\n", BUFSIZ);
	return 0;
}
