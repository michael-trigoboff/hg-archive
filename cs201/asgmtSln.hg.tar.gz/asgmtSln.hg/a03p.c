// child process counts number of characters in arguments to main,
// arguments are piped in from parent process

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>         // for pipe()
#include <sys/wait.h>       // for waitpid()

static int      comm[2];

int main (int argc, char **argv)
{
    pid_t   pid;

	printf("CS201 - Assignment 3 - Michael Trigoboff\n");

    // set up pipe
    if (pipe(comm)) {
        printf("pipe error\n");
        return -1;
        }

    // fork into parent and child processes
    pid = fork();

    // fork() failed
    if (pid < 0) {
        printf("fork error %d\n", pid);
        return -1;
        }

    // code that runs in the child process
    else if (pid == 0) {
		int		sum = 0;
        int		n;

        close(comm[1]);     // child doesn't need output side of pipe
        while (read(comm[0], &n, 4) != 0) {
            // read() will immediately return a zero once the pipe
            // has been closed by the parent process
            //printf("child: read '%c'\n", c);
			sum += n;
            }
        close(comm[0]);
        return sum;
        }

    // code that runs in the parent process
    else {
        int     i;
		char	c;
        int		n;
        int     status;

        close(comm[0]);     // parent doesn't need input side of pipe
        //printf("parent: forked child process %u\n", pid);
        for (i = 1; i < argc; i++) {
            n = atoi(argv[i]);
			write(comm[1], &n, 4);
            }
        close(comm[1]);

        // wait for child to finish, check status
        waitpid(pid, &status, 0);
        //printf("parent: reaps child status 0x%08X\n", status);
        //if (WIFEXITED(status))
        //    printf("parent: child exited normally with %d\n", WEXITSTATUS(status));
        //printf("parent exits\n");
        c = WEXITSTATUS(status);
        printf("sum = %d\n", c);
        return 0;
        }
}
