/*	On syccuxfs01.pcc.edu, math.h will only #include /usr/include/bits/nan.h
 *	if gcc is called with -std=c99. The NAN constant is contained in nan.h.
 *	The nan(0) function is not part of the ANSI standard, and should not be used.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PRECISION            3
#define RND_CTL_BIT_SHIFT   10

// floating point rounding modes: IA-32 Manual, Vol. 1, p. 4-20
typedef enum {
    ROUND_NEAREST_EVEN =    0 << RND_CTL_BIT_SHIFT,
    ROUND_MINUS_INF =       1 << RND_CTL_BIT_SHIFT,
    ROUND_PLUS_INF =        2 << RND_CTL_BIT_SHIFT,
    ROUND_TOWARD_ZERO =     3 << RND_CTL_BIT_SHIFT
} RoundingMode;


double roundD (double n, RoundingMode roundingMode)
{
    short       fpuCtlSave;
    short       fpuCtl;
    short       roundingCtlMask = ~(0x0003 << 10);  // IA-32 Manual, Vol. 1, p. 8-9

    // get current value of FPU control word
    __asm(
        "   fstcw   %[fpuCtlSave]   \n"
        : [fpuCtlSave]  "=m"    (fpuCtlSave)    // outputs
    );

    // set rounding control to "round towards zero"
    fpuCtl = fpuCtlSave;
    fpuCtl &= roundingCtlMask;
    fpuCtl |= roundingMode;
    __asm(
        "   fldcw   %[fpuCtl]       \n"
        :                                       // outputs
        : [fpuCtl]      "m"     (fpuCtl)        // inputs
    );

    // generate truncated value
    __asm(
        "   fldl    %[nIn]      \n"
        "   frndint             \n"
        "   fstpl   %[nOut]     \n"
        : [nOut]    "=m"    (n)                 // outputs
        : [nIn]     "m"     (n)                 // inputs
    );

    // restore saved value of FPU control word
    __asm(
        "   fldcw   %[fpuCtlSave]   \n"
        :                                       // outputs
        : [fpuCtlSave]  "m"     (fpuCtlSave)    // inputs
    );

    return n;
}

double powD (double n, double exp)
{
// do not change anything above this comment

    double      signFactor = 1.0;   // used to make result negative if necessary
    double      expLog2n;
    double      expLog2nTrunc;
    double      twoEL2NT;           // 2^expLog2nTrunc
    double      expLog2nFract;
    double      twoEL2NF;           // 2^expLog2nFract

    // fyl2x instruction requires positive n,
    // so record if n is negative and then make it positive
    if (n < 0) {
        double      expTrunc;
        int         expInt;

        expTrunc = roundD(exp, ROUND_TOWARD_ZERO);
        expInt = expTrunc;
        if (expTrunc != exp)
            // non-integer exp not allowed when n is negative
            return NAN;             // argument is ignored
        n *= -1;
        signFactor = (expInt & 0x00000001) ? -1 : 1;    // is exp odd?
        }
    // special cases for n == 0.0
    else if (n == 0.0)
        return exp > 0.0  ?     0.0 :
               exp == 0.0 ?     1.0 :
               /* exp < 0.0 */  -0x1.0p1024L;   // -infinity

    // compute exp*log2(n)
    __asm(
        "   fldl    %[exp]          \n"     // exp
        "   fldl    %[n]            \n"     // n exp
        "   fyl2x                   \n"     // exp*log2(n)
        "   fstpl   %[expLog2n]     \n"     // (empty)
        : [expLog2n]    "=m"    (expLog2n)      // outputs
        : [n]           "m"     (n),            // inputs
          [exp]         "m"     (exp)
    );

    expLog2nTrunc = roundD(expLog2n, ROUND_TOWARD_ZERO);
    expLog2nFract = expLog2n - expLog2nTrunc;

    // compute 2^expLog2nTrunc
    __asm(
        "   fldl    %[el2nt]        \n"     // expLog2nTrunc
        "   fld1                    \n"     // 1 expLog2nTrunc
        "   fscale                  \n"     // 2^expLog2nTrunc expLog2nTrunc
        "   fstp    %%st(1)         \n"     // 2^expLog2nTrunc
        "   fstpl   %[twoEL2NT]     \n"     // (empty)
        : [twoEL2NT]    "=m"    (twoEL2NT)      // outputs
        : [n]           "m"     (n),            // inputs
          [el2nt]       "m"     (expLog2nTrunc)
    );

    // compute 2^expLog2nFract
    __asm(
        "   fldl    %[expL2NF]      \n"     // expLog2nFract
        "   f2xm1                   \n"     // 2^(expLog2nFract)-1
        "   fld1                    \n"     // 1 2^(expLog2nFract)-1
        "   faddp                   \n"     // 2^(expLog2nFract)
        "   fstpl   %[twoEL2NF]     \n"     // (empty)
        : [twoEL2NF]    "=m"    (twoEL2NF)      // outputs
        : [expL2NF]     "m"     (expLog2nFract) // inputs
    );

    return signFactor * twoEL2NT * twoEL2NF;

// do not change anything below this comment, except for printing out your name
}

int main (int argc, char **argv)
{
    double  n = 0.0;
    double  exp = 0.0;

    printf("CS201 - Assignment 02sp - Michael Trigoboff\n");
    if (argc > 1)
        n = atof(argv[1]);
    if (argc > 2)
        exp = atof(argv[2]);

	// prints out what the assignment requires
    printf("%.*f to the %.*f = %.*f\n",
           PRECISION, n, PRECISION, exp, PRECISION, powD(n, exp));
    printf("%.*f to the %.*f = %.*f\n",
           PRECISION, n, PRECISION, exp, PRECISION, pow(n, exp));

    return 0;
}
