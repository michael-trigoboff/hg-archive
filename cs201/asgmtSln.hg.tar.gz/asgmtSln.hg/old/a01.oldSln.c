#include <stdio.h>
#include <stdlib.h>

int main (int argc, char **argv)
{
    short   probe = 0x0102;
    float   f;
    int     n;
    int     nValues;                        // number of values parsed by scanf

    printf("CS201 - A01 - Michael Trigoboff\n\n");

    printf("byte order: %s-endian\n\n",
           *((char *) &probe) == 0x01? "big" : "little");

    for (;;) {
        printf("> ");
        nValues = scanf("%f", &f);
        if (nValues != 1) {                 // encountered bad input
            printf("bad input\n");
            while (getchar() != '\n') ;     // flush bad input line
            continue;
            }
        n = f;
        printf("%10d 0x%0*X\n", n, sizeof(int) * 2, n);
        printf("%10.2f 0x%0*X\n", f, sizeof(int) * 2, *((int *) &f));
        if (f == 0.0)
            break;
        }
    printf("\n");
    return 0;
}
