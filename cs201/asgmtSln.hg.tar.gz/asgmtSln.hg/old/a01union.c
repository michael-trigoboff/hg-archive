#include <stdio.h>
#include <stdlib.h>

typedef union {
    int     intValue;
    float   floatValue;
    }
IntOrFloat;

int main (int argc, char **argv)
{
    IntOrFloat  n;
    int         nValues;                    // number of values parsed by scanf
    
    printf("CS171 - A02(union) - Michael Trigoboff\n");
    for (;;) {
        printf("> ");
        nValues = scanf("%f", &n.floatValue);
        if (nValues != 1) {                 // encountered bad input
            printf("bad input\n");
            while (getchar() != '\n') ;     // flush bad input line
            continue;
            }
        printf("%10d 0x%0*X\n", (int) n.floatValue, sizeof(n.intValue) * 2, (int) n.floatValue);
        printf("%10.2f 0x%0*X\n", n.floatValue, sizeof(n.intValue) * 2, n.intValue);
        if (n.floatValue == 0.0)
            break;
        }
    return 0;
}
