#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PRECISION   3

void quadraticRootsC(double roots[2], double a, double b, double c)
{
	double sqrtDiscr = sqrt(b * b - 4 * a * c);

	roots[0] = (-b + sqrtDiscr) / 2 * a;
	roots[1] = (-b - sqrtDiscr) / 2 * a;
}

void quadraticRoots(double roots[2], double a, double b, double c)
{
	double	four = 4.0;
	double	two = 2.0;

	asm(
		"	fldl	%[b]				\n"		// b
		"	fchs						\n"		// -b
		"	fld		%%st(0)				\n"		// -b -b
		"	fmul	%%st(0), %%st(0)	\n"		// b^2 -b
		"	fldl	%[four]				\n"		// 4 b^2 -b
		"	fmull	%[a]				\n"		// 4a b^2 -b
		"	fmull	%[c]				\n"		// 4ac b^2 -b
		"	fsubrp						\n"		// b^2-4ac -b
		"	fsqrt						\n"		// sqrt(b^2-4ac) -b
		"	faddp						\n"		// sqrt(b^2-4ac)-b
		"	fldl	%[two]				\n"		// 2 sqrt(b^2-4ac)-b
		"	fmull	%[a]				\n"		// 2a sqrt(b^2-4ac)-b
		"	fdivrp						\n"		// (sqrt(b^2-4ac)-b)/2a
		"	fstpl	%[root]				\n"		// (empty stack)
		: [roots]	"=m"	(roots)		// outputs
		: [four]	"m"		(four),		// inputs
		  [two]		"m"		(two),
		  [a]		"m"		(a),
		  [b]		"m"		(b),
		  [c]		"m"		(c)
	);

	roots[0] ;
}

int main (int argc, char **argv)
{
	double	a, b, c;
	double	root, rootC;

	printf("CS201 - Assignment 02 - Michael Trigoboff\n");
	if (argc != 4) {
		printf("need 3 arguments: a, b, c\n");
		return -1;
		}
	a = atof(argv[1]);
	b = atof(argv[2]);
	c = atof(argv[3]);
	root = quadraticRoot(a, b, c);
	rootC = quadraticRootC(a, b, c);

	printf("quadraticRoot(%.3f, %.3f, %.3f) = %.3f, %.3f\n", a, b, c, root, rootC);

	return 0;
}
