// starter file for Assignment 3

#include <stdio.h>
#include <stdlib.h>

#define PRECISION   3

double absD (double n)
{
    double      val;

    asm(
        "   fldl    %[n]        \n"     // n
        "   fabs                \n"     // abs(n)
        "   fstpl   %[val]      \n"     // (empty stack)
        : [n]   "=m"    (n)             // outputs
        : [val] "m"     (val)           // inputs
    );

    return val;
}

int main (int argc, char **argv)
{
    double  n = 0.0;

    printf("CS201 - Assignment 02 - Michael Trigoboff\n");
    if (argc > 1)
        n = atof(argv[1]);

    printf("abs(%.*f) = %.*f\n", PRECISION, n, PRECISION, absD(n));

    return 0;
}
