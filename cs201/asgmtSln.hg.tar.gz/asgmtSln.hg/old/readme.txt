a02sp needs to be compiled with -std=c99 for NaN constant
