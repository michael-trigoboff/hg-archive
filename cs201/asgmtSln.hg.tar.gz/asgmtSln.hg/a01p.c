// do not change this code except in the following ways:
//   * write code for the following functions:
//      * bigOrSmallEndian()
//      * getNextHexInt()
//      * printLinesForNumber()
//   * change studentName by changing "I. Forgot" to your actual name

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define EXPBIAS     127

static char *studentName = "Michael Trigoboff";

// report whether machine is big or small endian
void bigOrSmallEndian()
{
    short   probe = 0x0102;

    printf("byte order: %s-endian\n\n",
           *((char *) &probe) == 0x01? "big" : "little");
}

// get next int (specified in hex) using scanf()
bool getNextHexInt(unsigned int *iPtr)
{
    return scanf("%x", iPtr);
}

// print requested data for the given number
void printNumberData(int i)
{
    int     signBit = (i & 0x80000000) ? 1 : 0;
    int     expBits = (i & 0x7F800000) >> 23;
    int     fractBits = i & 0x007FFFFF;

    printf("signBit %1d, expBits %3u, fractBits 0x%08X\n", signBit, expBits, fractBits);

    if (expBits == 0) {                 // zero or denormalized
        if (fractBits == 0)                 // zero
            printf("%szero\n", signBit ? "-" : "+");
        else                                // denormalized
            printf("denormalized: exp = %3d\n", 1 - EXPBIAS);
        }
    else if (expBits == 0xFF) {         // infinity or NaN
        if (fractBits == 0)
            printf("%sinfinity\n", signBit ? "-" : "+");
        else
            printf("%sNaN\n", (fractBits & 0x00400000) ? "Q" : "S");
        }
    else                        		// normalized
        printf("normalized:   exp = %3d\n", expBits - EXPBIAS);
    printf("\n");
}

// do not change this function in any way
int main(int argc, char **argv)
{
	unsigned int	i;					// number currently being analyzed
	bool			validInput;			// was user input valid?

	printf("CS201 - A01p - %s\n\n", studentName);
	bigOrSmallEndian();
	for (;;) {
		if (argc == 1)						// allow grading script to control ...
			printf("> ");					// ... whether prompt character is printed
		validInput = getNextHexInt(&i);
		printf("0x%08X\n", i);
		if (! validInput) {					// encountered bad input
			printf("bad input\n");
			while (getchar() != '\n') ;		// flush bad line from input buffer
			continue;
			}
		printNumberData(i);
		if (i == 0) {
			printf("bye...\n");
			break;
			}
		}
	printf("\n");
	return 0;
}
