a02sp needs to be compiled with -lm
