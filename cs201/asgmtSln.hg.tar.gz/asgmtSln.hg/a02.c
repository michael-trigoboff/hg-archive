#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double hullSpeed(double lgth)
{
	double	hullSpd;
	double	coefficient = 1.34;

	asm(
		"		fldl	%[lgth]			\n"
		"		fsqrt					\n"
		"		fldl	%[coeff]		\n"
		"		fmulp					\n"
		"		fstpl	%[hullSpd]		\n"
		:	[hullSpd]	"=m"		(hullSpd)
		:	[lgth]		"m"			(lgth),
			[coeff]		"m"			(coefficient)
	);
	
	return hullSpd;
}

double hullSpeedC(double lgth)
{
	return 1.34 * sqrt(lgth);
}

int main (int argc, char **argv)
{
	double	lgth;
	double	hullSpd, hullSpdC;

	printf("CS201 - Assignment 02 - Michael Trigoboff\n");
	if (argc != 2) {
		printf("need 1 argument: boat length\n");
		return -1;
		}
	lgth = atof(argv[1]);
	hullSpd = hullSpeed(lgth);
	hullSpdC = hullSpeedC(lgth);

	printf("hullSpeed(%.0f) = %.3f, %.3f\n", lgth, hullSpd, hullSpdC);

	return 0;
}
