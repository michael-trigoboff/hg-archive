#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define RND_CTL_BIT_SHIFT   10

// IA-32 Manual, Vol. 1, p. 8-9
static short    roundCtlMask = ~(0x0003 << RND_CTL_BIT_SHIFT);

// floating point rounding modes: IA-32 Manual, Vol. 1, p. 4-20
typedef enum {
    ROUND_NEAREST_EVEN =    0 << RND_CTL_BIT_SHIFT,
    ROUND_MINUS_INF =       1 << RND_CTL_BIT_SHIFT,
    ROUND_PLUS_INF =        2 << RND_CTL_BIT_SHIFT,
    ROUND_TOWARD_ZERO =     3 << RND_CTL_BIT_SHIFT
} RoundingMode;

double roundD(double n, RoundingMode roundingMode)
{
// do not change anything above this comment

    short       fpuCtlSave;
    short       fpuCtl;

    // get current value of FPU control word
    asm(
        "   fstcw   %[fpuCtlSave]   \n"
        : [fpuCtlSave]  "=m"    (fpuCtlSave)    // outputs
    );

    // set rounding control to "round towards zero"
    fpuCtl = fpuCtlSave;
    fpuCtl &= roundCtlMask;
    fpuCtl |= roundingMode;
    asm(
        "   fldcw   %[fpuCtl]       \n"
        :                                       // outputs
        : [fpuCtl]      "m"     (fpuCtl)        // inputs
    );

    // generate truncated value
    asm(
        "   fldl    %[nIn]      \n"
        "   frndint             \n"
        "   fstpl   %[nOut]     \n"
        : [nOut]    "=m"    (n)                 // outputs
        : [nIn]     "m"     (n)                 // inputs
    );

    // restore saved value of FPU control word
    asm(
        "   fldcw   %[fpuCtlSave]   \n"
        :                                       // outputs
        : [fpuCtlSave]  "m"     (fpuCtlSave)    // inputs
    );

    return n;

// do not change anything below this comment, except for printing out your name
}double hullSpeed(double lgth)
{
	double	hullSpd;
	double	coefficient = 1.34;

	asm(
		"		fldl	%[lgth]			\n"
		"		fsqrt					\n"
		"		fldl	%[coeff]		\n"
		"		fmulp					\n"
		"		fstpl	%[hullSpd]		\n"
		:	[hullSpd]	"=m"		(hullSpd)
		:	[lgth]		"m"			(lgth),
			[coeff]		"m"			(coefficient)
	);
	
	return hullSpd;
}

double hullSpeedC(double lgth)
{
	return 1.34 * sqrt(lgth);
}

int main (int argc, char **argv)
{
	double	lgth;
	double	hullSpd, hullSpdC;
	char	*formatStr = "%s hullSpeed(%.0f) = %.0f, %.0f\n";

	printf("CS201 - Assignment 02 - Michael Trigoboff\n");
	if (argc != 2) {
		printf("need 1 argument: boat length\n");
		return -1;
		}
	lgth = atof(argv[1]);
	hullSpd = hullSpeed(lgth);
	hullSpdC = hullSpeedC(lgth);

	printf("hullSpeed(%.0f) = %.3f, %.3f\n", lgth, hullSpd, hullSpdC);
	printf(formatStr, "round even:", lgth,
		   roundD(hullSpd,  ROUND_NEAREST_EVEN),
		   roundD(hullSpdC, ROUND_NEAREST_EVEN));
	printf(formatStr, "round down:", lgth,
		   roundD(hullSpd,  ROUND_MINUS_INF),
		   roundD(hullSpdC, ROUND_MINUS_INF));
	printf(formatStr, "round up:  ", lgth,
		   roundD(hullSpd,  ROUND_PLUS_INF),
		   roundD(hullSpdC, ROUND_PLUS_INF));
	printf(formatStr, "round zero:", lgth,
		   roundD(hullSpd,  ROUND_TOWARD_ZERO),
		   roundD(hullSpdC, ROUND_TOWARD_ZERO));

	return 0;
}
